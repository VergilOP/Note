public class ClassName {

    public void aMethod(){
    //variables and other statements here
    }

    public static void main(String[] args) {
        ClassName anObj = new ClassName();
        anObj.aMethod();
    }
}
