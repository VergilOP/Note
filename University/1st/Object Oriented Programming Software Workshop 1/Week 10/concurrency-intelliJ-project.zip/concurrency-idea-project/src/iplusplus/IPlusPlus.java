package iplusplus;

public class IPlusPlus {
    private static int i = 0;
    public static void main(String[] args){
        i++;
    }
}
