package fsd.week1.todolist1;

import fsd.week1.todolist1.datamodel.ToDoItem;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private List<ToDoItem> toDoItems;

    @FXML
    private ListView<ToDoItem> toDoListView;

    @FXML
    private TextArea itemDetailsTextArea;

    public void initialize() {
        ToDoItem item1 = new ToDoItem("Post birthday card", "Buy and write out birthday card",
                LocalDate.of(2022, Month.JULY, 17));
        ToDoItem item2 = new ToDoItem("Weekend away", "Book for the weekend away and get pets booked in",
                LocalDate.of(2022, Month.APRIL, 10));
        ToDoItem item3 = new ToDoItem("Plan birthday party", "Send out invites for the birthday and book venue",
                LocalDate.of(2022, Month.SEPTEMBER, 01));
        ToDoItem item4 = new ToDoItem("Get car serviced", "Book a service date for before we go away for the weekend",
                LocalDate.of(2022, Month.MARCH, 05));
        ToDoItem item5 = new ToDoItem("Assignments for FSD", "Plan for assignment deadlines in term 2",
                LocalDate.of(2022, Month.JANUARY, 25));
        toDoItems = new ArrayList<ToDoItem>();
        toDoItems.add(item1);
        toDoItems.add(item2);
        toDoItems.add(item3);
        toDoItems.add(item4);
        toDoItems.add(item5);

        //populate the toDoListView
        toDoListView.getItems().setAll(toDoItems);
        //set it to select one item at a time
        toDoListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    @FXML
    public void handleClickListView(){
        //this is backed by a selectionModel - get the selected item to retrieve the item from the model
        ToDoItem item = toDoListView.getSelectionModel().getSelectedItem();
        //delete the cast and you get an error so specify a type <ToDoItem>
        //System.out.println("The selected item is: "+item);
        StringBuilder sb = new StringBuilder(item.getDetails());
        sb.append("\n\n\n\n");
        sb.append("Due: ");
        sb.append(item.getDeadline().toString());
        itemDetailsTextArea.setText(sb.toString());
    }
}