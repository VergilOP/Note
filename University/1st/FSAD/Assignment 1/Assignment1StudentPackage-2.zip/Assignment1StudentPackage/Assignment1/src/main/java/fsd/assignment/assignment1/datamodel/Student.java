package fsd.assignment.assignment1.datamodel;

public class Student {
    private String studId;
    private String yearOfStudy;
    private String module1;
    private String module2;
    private String module3;

    /* TODO: the constructor must accept parameters so that all
             instance variables are set accordingly
    */
    public Student() {

    }

    /* TODO: ensure that all getters are included here
    */

    /* TODO: include a toString() that returns studId
    */

}
