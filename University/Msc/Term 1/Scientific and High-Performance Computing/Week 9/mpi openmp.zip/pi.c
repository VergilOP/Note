/*
	This code is based on that found below, with adaptation for our pedagogy.
*/

/*
	Authors: 	Dieter an Mey, Thomas Reichstein
	Published: 	hpc-wiki.info, 26 October 2017
	URL:		https://hpc-wiki.info/mediawiki/hpc_images/6/6d/OpenMP_and_MPI_for_Dummies-C.pdf
*/
/*
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>
#include <omp.h>
#define PI 3.1415926535897932384626433832795029L

double f(double a) { 
	return 4.0/(1.0 + (a*a)); 
}

int main(int argc, char *argv[]){
	int n, myid, numprocs, i;
	double mypi, pi, h, sum, x;
	
	MPI_Init(&argc, &argv );
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs );
	MPI_Comm_rank(MPI_COMM_WORLD, &myid );
	
	n = 0;
	for (int j=0; j<1000000; j++){
		if (j%1000){
			printf("j = %d.\n", j);
		}
		if ( myid == 0) { 
			printf(" Enter ...: (0 quits ) " ); 
			scanf( " %d " , &n); 
		}
		MPI_Bcast (&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
		if (n == 0){
			break;
		} else{
			h = 1.0 / ( double ) n ;
			sum = 0.0;
			#pragma omp parallel for reduction (+:sum) private(i, x)
			for (i = myid + 1; i <= n; i += numprocs){
				x = h * (( double )i - 0.5);
				sum += f ( x );
			}
			mypi = h * sum ;
			MPI_Reduce(&mypi, &pi, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
			if ( myid == 0){ 
				printf("Pi = %lf, error = %lf \n ", pi, fabs(pi - PI)); 
			}
		}
	}
	MPI_Finalize();
	return EXIT_SUCCESS ;
}
*/
///*
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <omp.h>
#include <math.h>

const long NPTS=10000000;
const int NLOOP=10;
#define PI 3.1415926535897932384626433832795029L

double f(double x){
	return 4.0/(1.0 + x*x);
}

int main(int argc, char** argv) {
	int rank,nproc, j;
	long i,istart,iend;
	double sum,pi,start,end,mflops,maxflops=0.0;
	double x;
	
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&nproc);
	
	istart 	= (rank+0)*NPTS / nproc;
	iend 	= (rank+1)*NPTS / nproc;
	
	// We always loop our benchmarking
	for (j = 0; j < NLOOP; ++j) {
	
		//MPI_Barrier(MPI_COMM_WORLD);
		if (rank == 0){
			start = omp_get_wtime();
		}
		sum = 0.0;
		#pragma omp parallel for reduction(+:sum) private(x)
		for (i = istart; i <= iend; i++){ 
		    x = (double)i/(double)NPTS;
			sum += f(x);
		}
		sum = sum / (double)NPTS;
		MPI_Reduce(&sum,&pi,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
		
		if (rank == 0){
			end = omp_get_wtime();
			mflops = 1.0e-6*(nproc*NPTS*5.0)/(end-start); // (1 mflop / 1 flop) * # of flop / # of seconds
			printf("processes = %d, threads = %d, NPTS = %ld, pi = %2.16f, error = %e\n",nproc,omp_get_max_threads(),NPTS,pi,fabs(PI-pi));
			if (mflops > maxflops) maxflops = mflops;
			printf("time = %f, estimated MFlops = %f (%f)\n",(end-start),mflops,maxflops);
		}
	
	}
	
	MPI_Finalize();
	return 0;	
}
//*/
