#include <stdio.h>
#include <mpi.h>
#include <omp.h>

int main(int argc, char *argv[])
{
    int numprocs, rank, namelen, iam, np;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    
    
    
    
    
    {
        
        
        printf("Hybrid: Hello from thread %d out of %d from process %d out of %d on %s\n",
            iam, np, rank, numprocs, processor_name);
    }

    MPI_Finalize();

    return 0;
}