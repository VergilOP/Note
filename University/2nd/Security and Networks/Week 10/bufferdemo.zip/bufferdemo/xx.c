#include <unistd.h>
#include <stdlib.h>

int main(void)
{
   setuid(0);
   system("reboot");
   
   return 0;
} 

