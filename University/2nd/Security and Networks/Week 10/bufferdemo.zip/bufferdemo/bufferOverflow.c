#include <stdio.h>

void getname() 
{
    char buffer[32];


    gets(buffer);
    printf("By the way buffer is at: %p\n", &buffer[0]);
    printf("Your name is %s.\n", buffer);
}

int main(void) 
{
    printf("Enter your name:" );
    getname();
    return 0;
}
