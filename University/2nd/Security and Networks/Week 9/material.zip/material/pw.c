#include <string.h>
#include <stdio.h>

const char* pw = "h4xxor";

int main(void)
{
	char buffer[64];
	printf("Say the passwooord: \n");
    gets(buffer);
	
	if(strcmp(buffer, pw) == 0)
	{
		printf("Well done!\n");
	}
	else
	{
		printf("WRONG - this incident will be reported\n");
	}
	
	return 0;
		
}