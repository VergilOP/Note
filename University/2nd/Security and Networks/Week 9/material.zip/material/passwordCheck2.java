import java.io.IOException;

public class passwordCheck2 {
    public static void main(String[] args) throws IOException {
	java.io.BufferedReader stdin = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
	while (true) {
	    System.out.println("Enter password:");
	    String line = stdin.readLine();
	    if (checkline(line)) {
		System.out.println("Well done, that is the correct password"); 
		System.exit(0);
	    } else {
		System.out.println("Incorrect password"); 
	    }  
	}
    }

    public static boolean checkline(String input) {
	try{
	    int value = Integer.parseInt(input);
	    if (value < 1000 || value > 99999) return false;
	    int char1 = Character.getNumericValue(input.charAt(1));
	    int char2 = Character.getNumericValue(input.charAt(2));
	    int char3 = Character.getNumericValue(input.charAt(3));
	    if (char1+char2 != char3) return  false;
	    return true;
	} catch (Exception E) {
	    return false;
	}
    }
    
    
    
}
