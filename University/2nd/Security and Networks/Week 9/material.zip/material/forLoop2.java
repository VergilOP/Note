
public class forLoop2 {
    
    public static void main (String[] args) {
	int j =1;
	    for(int i=1;i<4;i++) {
		j = j+i;
		System.out.println(j);
	    }
    }
}
