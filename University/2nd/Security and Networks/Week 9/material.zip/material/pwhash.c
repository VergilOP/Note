#include <string.h>
#include <stdio.h>
#include <crypt.h>

// const char* pw = "h4xxor";
const char *pw = "ab3z4hnHA5WdU";
const char *salt = "ab";

int main(void)
{
	char buffer[64];
	printf("Say the passwooord: \n");
    gets(buffer);
	
        if (strcmp (crypt (buffer, salt), pw) == 0)
	{
		printf("Well done!\n");
	}
	else
	{
		printf("WRONG - this incident will be reported\n");
	}
	
	return 0;
		
}
