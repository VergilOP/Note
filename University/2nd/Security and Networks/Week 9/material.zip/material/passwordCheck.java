import java.io.IOException;

public class passwordCheck {
	public static void main(String[] args) throws IOException {
		java.io.BufferedReader stdin = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
		while (true) {
			System.out.println("Enter password:");
			String line = stdin.readLine();
			if (line.equals("2345")) {
				System.out.println("Well done, that is the correct password"); 
				System.exit(0);
			} else {
				System.out.println("Incorrect password"); 
			}  
		}
	}
}
