#include<stdio.h>
#include<stdlib.h>
#include "cpucycles.c"

#include "matmul-naive.c"
#include "matmul-row-col.c"
#include "tiled-matmul-row-col.c"


// Fills a matrix of size n x n with random data
void fill(double* p, int n)
{
  for (int i = 0; i < n; ++i)
    p[i] = 2*drand48()-1; 	// Uniformly distributed over [-1, 1]
}

// Prints a matrix of size n x n
void print(double* p, int n)
{
  	for (int i = 0; i < n; ++i)
  	{
		for (int j = 0; j < n; ++j)
			printf("%f \t", p[i*n+j]);
		printf("\n");
	}		
}


int main(){
	int i, j, k;
	double *A, *A_t, *B, *C1, *C2;
	unsigned long long CLOCK_start, CLOCK_end, CLOCK_total;
	long int COUNTER, REPEAT=4;
	int n;
	float difference;

	for(n=8; n<2048; n=n*2)
	{	

		A = malloc(n*n*sizeof(double));
		A_t = malloc(n*n*sizeof(double));
		B = malloc(n*n*sizeof(double));
		C1 = malloc(n*n*sizeof(double));
		C2 = malloc(n*n*sizeof(double));
		
		fill(A, n*n);
		fill(B, n*n);
		fill(C1, n*n);

		// A_t = transpose(A)
		// C2 = C1
		for(i=0; i<n; i++)
		{
			for(j=0; j<n; j++)
			{	
				A_t[i*n+j] = A[i+j*n];				
				C2[i*n+j] = C1[i*n+j];
			}			
		}
			
		CLOCK_total=0;
		for(COUNTER=0; COUNTER<REPEAT; COUNTER++)
		{
			CLOCK_start = cpucycles();
			matmul_naive(n, A, B, C1);
			//matmul_row_col(n, A, B, C1);		
			CLOCK_end = cpucycles();
			CLOCK_total = CLOCK_total + CLOCK_end - CLOCK_start;
		}
		printf("n=%d Avg cycle count = %llu\n", n, CLOCK_total/REPEAT);

		CLOCK_total=0;
		for(COUNTER=0; COUNTER<REPEAT; COUNTER++)
		{
			CLOCK_start = cpucycles();
			matmul_row_col(n, A, B, C2);
			//tiled_matmul_row_col(n, A_t, B, C2);
			CLOCK_end = cpucycles();	
			CLOCK_total = CLOCK_total + CLOCK_end - CLOCK_start;
		}
		printf("n=%d Avg cycle count = %llu\n", n, CLOCK_total/REPEAT);
	
		// Check correctness by comparing C1 and C2
		difference = 0;		
		for(i=0; i<n; i++)
			for(j=0; j<n; j++)
			{	
				difference = difference + C1[i*n+j] - C2[i*n+j];
			}			
		printf("difference=%f\n", difference);
		
		free(A);
		free(A_t);
		free(B);
		free(C1);
		free(C2);
	}

}
