compilation command
gcc -O3 matmul.c
==== tiled-matmul-row-col.c File ====
In void tiled_matmul_row_col(int n, double* A_t, double* B, double* C), 
the minimum block size is set to int threshold = 64;
This value is a critical performance parameter. 
Play with this value and see how performance changes. 
