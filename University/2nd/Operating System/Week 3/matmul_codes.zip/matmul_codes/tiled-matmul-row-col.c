/* This file performs a matmul operation
 * C := C + A * B
 * where A, B, and C are n-by-n matrices stored in column-major format.
 * On exit, A and B maintain their input values. 
*/    


// This function computes C = C + A_t*B
// Assumes A_t is in row-major order
void multiply_block(int n, double* A_t, double* B, double* C)
{
	int i, j, k;
	double cij;

	for(i=0; i<n; ++i)
	{	
		for(j=0; j<n; ++j)
	      	{
			cij = C[i+j*n];
			for(k=0; k<n; ++k)
			{
		   		cij+=A_t[i*n+k]*B[j*n+k];
			}	
	      		C[i+j*n] = cij;
		}
 	}
}

// This function assumes that A_t is in row-major order
void tiled_matmul_row_col(int n, double* A_t, double* B, double* C)
{
	int i, j, k;
	double cij;
 	int threshold = 64;

	int block=n/2;
	double *A_t00 = malloc(block*block*sizeof(double));
 	double *A_t01 = malloc(block*block*sizeof(double));
	double *A_t10 = malloc(block*block*sizeof(double));
	double *A_t11 = malloc(block*block*sizeof(double));

	double *B00 = malloc(block*block*sizeof(double));
 	double *B01 = malloc(block*block*sizeof(double));
	double *B10 = malloc(block*block*sizeof(double));
	double *B11 = malloc(block*block*sizeof(double));

	double *C00 = malloc(block*block*sizeof(double));
 	double *C01 = malloc(block*block*sizeof(double));
	double *C10 = malloc(block*block*sizeof(double));
	double *C11 = malloc(block*block*sizeof(double));

	// Partitioning matrices into 2x2 submatrices
	for(i=0; i<block; i++)
	{
		for(j=0; j<block; j++)
		{
			A_t00[i*block+j] = A_t[i*n+j];
			A_t01[i*block+j] = A_t[i*n+j+block];
			A_t10[i*block+j] = A_t[n*n/2+i*n+j];
			A_t11[i*block+j] = A_t[n*n/2+i*n+j+block];

			B00[i*block+j] = B[i*n+j];
			B01[i*block+j] = B[i*n+j+block];
			B10[i*block+j] = B[n*n/2+i*n+j];
			B11[i*block+j] = B[n*n/2+i*n+j+block];

			C00[i*block+j] = C[i*n+j];
			C01[i*block+j] = C[i*n+j+block];
			C10[i*block+j] = C[n*n/2+i*n+j];
			C11[i*block+j] = C[n*n/2+i*n+j+block];
		}
	}

	// When n<=threshold, perform actual matrix multiplication
	if(n<=threshold)
	{
		multiply_block(n/2, A_t00, B00, C00);
		multiply_block(n/2, A_t00, B10, C10);

		multiply_block(n/2, A_t01, B01, C00);
		multiply_block(n/2, A_t01, B11, C10);

		multiply_block(n/2, A_t10, B00, C01);
		multiply_block(n/2, A_t10, B10, C11);

		multiply_block(n/2, A_t11, B01, C01);
		multiply_block(n/2, A_t11, B11, C11);
	}
	else
	{
		tiled_matmul_row_col(n/2, A_t00, B00, C00);
		tiled_matmul_row_col(n/2, A_t00, B10, C10);

		tiled_matmul_row_col(n/2, A_t01, B01, C00);
		tiled_matmul_row_col(n/2, A_t01, B11, C10);

		tiled_matmul_row_col(n/2, A_t10, B00, C01);
		tiled_matmul_row_col(n/2, A_t10, B10, C11);

		tiled_matmul_row_col(n/2, A_t11, B01, C01);
		tiled_matmul_row_col(n/2, A_t11, B11, C11);
	}

	for(i=0; i<block; i++)
	{
		for(j=0; j<block; j++)
		{
			C[i*n+j] = C00[i*block+j];
			C[i*n+j+block] = C01[i*block+j];

			C[n*n/2+i*n+j] = C10[i*block+j];
			C[n*n/2+i*n+j+block] = C11[i*block+j];
		}
	}

	free(A_t00);
	free(A_t01);
	free(A_t10);
	free(A_t11);
	free(B00);
	free(B01);
	free(B10);
	free(B11);
	free(C00);
	free(C01);
	free(C10);
	free(C11);
}


