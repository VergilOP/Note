//const char* dgemm_desc = "Naive, three-loop dgemm.";
 
/* This routine performs a matmul operation
 * C := C + A * B
 * where A, B, and C are n-by-n matrices stored in column-major format.
 * On exit, A and B maintain their input values. 
*/    

void matmul_row_col(int n, double* A, double* B, double* C)
{
	int i, j, k;
	double cij;

	// Transpose of A is A_t 	
	double *A_t = malloc(n*n*sizeof(double));
	for(i=0; i<n; i++)
		for(j=0; j<n; j++)
			A_t[i*n+j] = A[i+j*n];
 

	// matrix multiplication
	// A_t in row-major order 
	// B and C are in column-major order
	for(i=0; i<n; ++i)
	{	
		for(j=0; j<n; ++j)
   		{
			cij = C[i+j*n];
			for(k=0; k<n; ++k)
            {
            	cij+=A_t[i*n+k]*B[k+j*n];
			}	
      		C[i+j*n] = cij;
         }
 	}
	free(A_t);
}


